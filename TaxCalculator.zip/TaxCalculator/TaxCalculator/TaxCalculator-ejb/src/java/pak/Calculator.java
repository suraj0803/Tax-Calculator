/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pak;

import javax.ejb.Stateless;

/**
 *
 * @author Kuldeep Dwivedi
 */
@Stateless
public class Calculator implements CalculatorLocal {

    @Override
    public double calculateTax(String FullName, double income, double deductions) {
        
        double taxAmount = 0.0;
            double taxable = income - deductions;
            if(taxable>1000000.0)
            {
                taxAmount=taxable*0.3;
            }
            else if(taxable>800000.0 && taxable<1000000.0)
            {
                taxAmount=taxable*0.2;
            }
            else if(taxable>500000.0 && taxable<800000.0)
            {
                taxAmount=taxable*0.1;
            }
            else if(taxable>0.0)
            {
                taxAmount=taxable*0;
            }
        
        return taxAmount;
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
